<?php 

require_once("logger/includes/error_debug.php");
require_once("logger/includes/error.php");

$content = file_get_contents('php://input');

if ($_SERVER["HTTP_CONTENT_ENCODING"] == "gzip") {
    $content = gzdecode($content);
}

//var_dump($content);
//exit;

$message = json_decode($content, true);

if ($message['Token'] != "607bf405-a5a8-4b8c-aa61-41e8c1208dba") {
	header('HTTP/1.0 403 Forbidden');
	exit;
}

preg_match('/\b([0-9a-fA-F]{32})\b.*?(\[([^\]]*)\]\[([^\]]*)\]\[([^\]]*)\])\[0\]:?\s*(.*)/s', $message['Body'], $matches, PREG_OFFSET_CAPTURE);

$recType = $matches[5][0];

$appName = $matches[4][0];

$hash = $matches[1][0];

$message = "($appName) ($hash) ".$matches[6][0];

$logRecType;

switch($recType) 
{
    case 'Trace':
        $logRecType = LogRecType::Trace;
        break;
    case 'Debug':
        $logRecType = LogRecType::Debug;
        break;
    case 'Info':
        $logRecType = LogRecType::Info;
        break;
    case 'UserAction':
        $logRecType = LogRecType::UserAction;
        break;
    case 'Action':
        $logRecType = LogRecType::Action;
        break;
    case 'UserWarning':
        $logRecType = LogRecType::UserWarning;
        break;
    case 'UserError':
        $logRecType = LogRecType::UserError;
        break;
    case 'Warning':
        $logRecType = LogRecType::Warning;
        break;
    case 'Error':
        $logRecType = LogRecType::Error;
        break;
    case 'Fatal':
        $logRecType = LogRecType::Fatal;
        break;
    default:
        $logRecType = LogRecType::Error;
        break;
}

ErrorUtils::Log($logRecType, htmlspecialchars_decode($message), null, $hash);

?>