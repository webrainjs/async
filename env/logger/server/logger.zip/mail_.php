<?php 

require_once("logger/includes/error_debug.php");
require_once("logger/includes/error.php");

$content = file_get_contents('php://input');

if ($_SERVER["HTTP_CONTENT_ENCODING"] == "gzip") {
    $content = gzdecode($content);
}

//var_dump($content);
//exit;

$message = json_decode($content, true);

if ($message['Token'] != "607bf405-a5a8-4b8c-aa61-41e8c1208dba") {
  header('HTTP/1.0 403 Forbidden');
  exit;
}

require_once("logger/db/viewer/api/includes/db.php");

preg_match('/\b([0-9a-fA-F]{32})\b/s', $message['Body'], $matches1, PREG_OFFSET_CAPTURE);

$hash = $matches1[1][0];

$exist = $db->query("SELECT Id FROM Logs WHERE Id = UNHEX('{$hash}') LIMIT 1")->fetch_object()->Id;

if (!$exist) {
    preg_match('/\b([0-9a-fA-F]{32})\b.*?(\[([^\]]*)\]\[([^\]]*)\]\[([^\]]*)\])\[0\]:?\s*(.*)/s', $message['Body'], $matches2, PREG_OFFSET_CAPTURE);

    $messageBody = $matches2[6][0];

    preg_match('/\[([^\]]*)\]\[([^\]]*)\]\[([^\]]*)\]\[([^\]]*)\]/s', $message['Subject'], $matches3, PREG_OFFSET_CAPTURE);

    $appVersion = $matches3[1][0];

    $time = $matches3[2][0];

    $appName = $matches3[3][0];

    $recType = $matches3[4][0];

    $type;

    switch($recType) 
    {
        case 'Trace':
            $type = 1;
            break;
        case 'Debug':
            $type = 2;
            break;
        case 'Info':
            $type = 3;
            break;
        case 'UserAction':
        case 'Action':
            $type = 4;
            break;
        case 'UserWarning':
            $type = 5;
            break;
        case 'UserError':
            $type = 6;
            break;
        case 'Warning':
            $type = 7;
            break;
        case 'Error':
            $type = 8;
            break;
        case 'Fatal':
            $type = 9;
            break;
        default:
            $type = 8;
            break;
    }

    $messageBody = $messageBody ? htmlspecialchars_decode($messageBody) : "";
    $messageShort = $messageBody ? $db->real_escape_string(substr(strtok($messageBody, "\n"),0,100)) : "";
    $messageFull = $messageBody ? $db->real_escape_string($messageBody) : "";

    $appName = $appName ? $db->real_escape_string(htmlspecialchars(substr($appName,0,50), ENT_COMPAT | ENT_HTML401, 'UTF-8')) : "";

    $appVersion = $appVersion ? $db->real_escape_string(htmlspecialchars(substr($appVersion,0,50), ENT_COMPAT | ENT_HTML401, 'UTF-8')) : "";

    $query = <<<SQL
        INSERT IGNORE INTO Logs
        SET 
            Id = UNHEX('{$hash}'),
            TypeId = {$type},
            StatusId = 0,
            AppName = '$appName',
            AppVersion = '$appVersion',
            MessageShort = '$messageShort',
            MessageFull = '$messageFull';
SQL
;

    $db->query($query);

    if ($db->error) {
        ErrorUtils::Log(LogRecType::Error, htmlspecialchars($db->error, ENT_COMPAT | ENT_HTML401, 'UTF-8'));
        die();
    }
}

$ip = LogEvent::GetIP();

$db->query(<<<SQL
    INSERT INTO Events 
        (LogId, IP, LastTime, Count) VALUES (UNHEX('{$hash}'), INET_ATON('$ip'), NOW(), 1) 
    ON DUPLICATE KEY UPDATE    
        LastTime = NOW(), Count = Count + 1
SQL
);

if ($db->error) {
    ErrorUtils::Log(LogRecType::Error, htmlspecialchars($db->error, ENT_COMPAT | ENT_HTML401, 'UTF-8'));
    die();
}

?>